"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeserializeArray = exports.ObjectDeserialize = void 0;
const firestore_1 = require("@google-cloud/firestore");
const zod_1 = require("zod");
const DeserializeArray = (data, validator) => {
    let resultArray = new Array();
    for (let d of data) {
        let result = validator.safeParse(d.data());
        if (result.success) {
            resultArray.push(result.data);
        }
        else {
            console.log(result.error.message);
        }
    }
    return resultArray;
    // if (Array.isArray(data) && data.every(d => d instanceof DocumentSnapshot)) {
    //   let resultArray: Array<T> = new Array();
    //   for (let d of data) {
    //       let result = validator.safeParse(d.data())
    //       if (result.success) {
    //         resultArray.push(result.data as T)
    //       }
    //   }
    //   return resultArray;
    // }
};
exports.DeserializeArray = DeserializeArray;
const ObjectDeserialize = (data, validator) => {
    try {
        let objectData = {};
        // Handling a string type data.
        if (typeof data === "string") {
            objectData = JSON.parse(data);
        }
        // Handling a Document Snapshot type data.
        if (data instanceof firestore_1.DocumentSnapshot) {
            objectData = data.data();
        }
        validator.parse(objectData);
        return objectData;
    }
    catch (error) {
        if (error instanceof SyntaxError) {
            console.log(`Problem occured when deserializing the following string data - ${data}`);
        }
        if (error instanceof zod_1.ZodError) {
            console.log(`Problem occured when deserializing the data by using Zod framework - ${error.message}`);
        }
        throw error;
    }
};
exports.ObjectDeserialize = ObjectDeserialize;
