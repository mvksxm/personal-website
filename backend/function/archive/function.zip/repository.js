"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const firestore_1 = require("@google-cloud/firestore");
class Repository {
    constructor(projectId, databaseId, supportedCollections) {
        this.projectId = projectId;
        this.databaseId = databaseId;
        this.firestoreClient = new firestore_1.Firestore({
            projectId: projectId,
            databaseId: databaseId
        });
        this.supportedCollections = supportedCollections;
        // Default collection that is chosen for the init purposes.
        this.observedCollection = this.firestoreClient.collection("workExperience");
        //   .withConverter
        //   (
        //     this.collectionsConfig["workExperience"]["desFunction"]()
        //   );
    }
    //     private documentConverter<T extends object>() : FirestoreDataConverter<T> {
    //         return {
    //             toFirestore(item: T): DocumentData {
    //                 return { ...item };
    //             },
    //             fromFirestore(snapshot): T {
    //                 return snapshot.data() as T;
    //             }
    //         };
    //   }
    validateCollectionPath(collectionPath) {
        let pathRegex = new RegExp("^[a-zA-Z]+(\/[a-zA-Z]+)*$");
        return pathRegex.test(collectionPath) && this.supportedCollections.includes(collectionPath);
    }
    reInitCollection(collectionPath) {
        var _a;
        if (!this.validateCollectionPath(collectionPath)) {
            throw new Error(`Collection id provided - ${collectionPath} is invalid!`);
        }
        let currCollectionPath = (_a = this.observedCollection) === null || _a === void 0 ? void 0 : _a.path;
        if (currCollectionPath === null || currCollectionPath != collectionPath) {
            this.observedCollection = this.firestoreClient
                .collection(collectionPath);
            //   .withConverter
            // (
            //     this.collectionsConfig["workExperience"]["desFunction"]() 
            // );
        }
        return;
    }
    ListCollectionDocuments(collectionPath) {
        return __awaiter(this, void 0, void 0, function* () {
            this.reInitCollection(collectionPath);
            let documentRefs = yield this.observedCollection.listDocuments();
            if (documentRefs.length === 0) {
                throw new Error(`Collection - ${collectionPath} is empty!`);
            }
            return yield this.firestoreClient.getAll(...documentRefs);
        });
    }
    GetDocumentById(collectionPath, documentId) {
        return __awaiter(this, void 0, void 0, function* () {
            this.reInitCollection(collectionPath);
            let documentSnapshot = yield this.observedCollection.doc(documentId).get();
            if (!documentSnapshot.exists) {
                throw new Error(`Document with the following id - ${documentId} , does not exist in the provided collection - ${collectionPath}`);
            }
            return documentSnapshot;
        });
    }
}
exports.default = Repository;
