"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const repository_1 = __importDefault(require("./repository"));
const ff = __importStar(require("@google-cloud/functions-framework"));
const models_1 = require("./models");
const deserializers_1 = require("./deserializers");
const firestore_1 = require("@google-cloud/firestore");
const z = __importStar(require("zod"));
// Global Vars
const PROJECT_ID = process.env["project_id"] ? process.env["project_id"] : "marine-catfish-310009";
const DATABASE_ID = process.env["database_id"] ? process.env["database_id"] : "personal-database";
const SUPPORTED_COLLECTIONS = [
    "workExperience",
    "personalProjects"
];
// Repo definition
let rep = new repository_1.default(PROJECT_ID, DATABASE_ID, SUPPORTED_COLLECTIONS);
const ApplyCollectionType = (documentData, collectionName) => {
    let resultArray = [];
    if (!SUPPORTED_COLLECTIONS.includes(collectionName)) {
        // Not implemented
        throw new Error("Not implemented.");
    }
    if (collectionName == "workExperience") {
        if (documentData instanceof firestore_1.DocumentSnapshot) {
            resultArray.push((0, deserializers_1.ObjectDeserialize)(documentData, models_1.WorkExperienceSchema));
        }
        if (documentData instanceof Array) {
            resultArray = (0, deserializers_1.DeserializeArray)(documentData, models_1.WorkExperienceSchema);
        }
    }
    if (collectionName == "personalProjects") {
        // Not implemented
        throw new Error("Not implemented.");
    }
    return resultArray;
};
// Testing
// rep.ListCollectionDocuments("workExperience").then((docs => {
//    let workExpDocs: Array<WorkExperienceType> = DeserializeArray<WorkExperienceType>(docs, WorkExperienceSchema)
//    for (let doc of workExpDocs) {
//     console.log(doc.companyName)
//    }
// }))
// rep.GetDocumentById("workExperience", "QWJib3R0").then((doc) => {
//   let workExp: WorkExperienceType = ObjectDeserialize<WorkExperienceType>(doc, WorkExperienceSchema)
//   console.log(workExp.companyName)
// })
ff.http("PersonalFunction", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a;
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    if (req.method === "OPTIONS") {
        res.status(204).send('');
        return;
    }
    try {
        let rawRequest = (_a = req.rawBody) === null || _a === void 0 ? void 0 : _a.toString();
        if (!rawRequest) {
            throw new Error("Request's body is empty!");
        }
        let deserializedReq = (0, deserializers_1.ObjectDeserialize)(rawRequest, models_1.FunctionRequestSchema);
        // if (!deserializedReq.collectionName) {
        //   throw new Error("Obligatory parameter - 'collectionName' is empty!")
        // }  
        if (!deserializedReq.isList && !(deserializedReq === null || deserializedReq === void 0 ? void 0 : deserializedReq.documentId)) {
            throw new Error("If 'isList' parameters is - 'False', then 'documentId' must be supplied!");
        }
        let functionResponse;
        if (!deserializedReq.isList && deserializedReq.documentId) {
            let documentSnap = yield rep.GetDocumentById(deserializedReq.collectionName, deserializedReq.documentId);
            functionResponse = ApplyCollectionType(documentSnap, deserializedReq.collectionName);
        }
        else {
            let documentSnaps = yield rep.ListCollectionDocuments(deserializedReq.collectionName);
            functionResponse = ApplyCollectionType(documentSnaps, deserializedReq.collectionName);
        }
        res.status(200).send(functionResponse);
    }
    catch (error) {
        console.log("Error occured during an execution of the function!");
        let errorMessage;
        if (error instanceof z.ZodError) {
            let pretifiedError = z.prettifyError(error);
            errorMessage = pretifiedError.replace(/[\n\r]/g, ' ');
        }
        else {
            var err = error;
            errorMessage = err.message;
        }
        // throw error;
        res.status(400).send({ "error": errorMessage });
    }
}));
